<?php
	require('header.php');
	?>

<?php
	include_once('content.php');
	?>

<?php 
	include_once 'footer.php'; 
	?>