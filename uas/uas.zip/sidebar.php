<!-- membuat sidebar -->
<div class="sidebar">
  <div class="widget-box">
      <h3 class="title">Menu</h3>
      <ul>
          <li><a href="form_kategori.php">Tambah Kategori</a></li>
          <li><a href="form_tambah.php">Tambah Barang</a></li>
          <li><a href="barang.php">Data Barang</a></li>
          <li><a href="kategori.php">Data Kategori</a></li>
          <li><a href="#">Data User</a></li>
      </ul>
  </div>
  <!-- <div class="widget-box">
      <h3 class="title">Widget Text</h3>
      <p>Vestibulum lorem elit, iaculis in nisl volutpat, malesuada tincidunt arcu. Proin in leo fringilla, vestibulum mi porta, faucibus felis. Integer pharetra est nunc, nec pretium nunc pretium ac.</p>
  </div> -->

</div>