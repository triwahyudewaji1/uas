<!-- Membuat Navigasi-->
			<nav>
				<ul>
					<li class="active"><a href="index.html" title="Home"> Home </a></li>
					<li><a href="about.html" title="About">About </a></li>
					<li><a href="contact.html" title="Contact">Contact </a></li>
				</ul>
			</nav>
