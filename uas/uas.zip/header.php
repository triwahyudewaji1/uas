<head>
	<meta charset="utf-8">
	<!-- Berikut adalah pemanggilan file.css -->
	<link rel="stylesheet" type="text/css" href="style.css" />
	<title>Online Shop</title>
</head>
<body>
	<!-- Ini adalah container -->
	<div id="container">
		<!-- Membuat Header-->
			<header>
				<h1>Produk online</h1>
			</header>
		<!-- Membuat Navigasi-->
			<nav>
				<ul>
					<li class="">
						<a href="index.php" title="Home">Admin</a>
					</li>
					<li>
						<a href="about.html" title="About">Kontak</a>
					</li>
					<li>
						<a href="contact.html" title="Contact">Profil</a>
					</li>
					<li>
						<a href="home.php" title="Home">Home</a>
					</li>
				</ul>
			</nav>