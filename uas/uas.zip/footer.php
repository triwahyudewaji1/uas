<!-- membuat footer -->
<footer>
  <p>&copy; 2018 - Online Shop</p>
</footer>
</div>

</body>
</html>